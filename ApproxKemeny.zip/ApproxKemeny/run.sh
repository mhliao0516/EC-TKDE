eps_arr=(0.5 0.4 0.3 0.2 0.1)

for eps in "${eps_arr[@]}"
do
    julia -O3 main.jl graph/astro-ph.txt ${eps}
done

# for eps in "${eps_arr[@]}"
# do
#     julia -O3 main.jl graph/email-enron.txt ${eps} >> kemeny.txt
# done

# julia -O3 main.jl graph/dblp.txt 0.5 >> dblp_kemeny.txt

# for eps in "${eps_arr[@]}"
# do
#     julia -O3 main.jl graph/dblp.txt ${eps} >> kemeny.txt
#     julia -O3 main.jl graph/youtube.txt ${eps} >> kemeny.txt
#     julia -O3 main.jl graph/pokec.txt ${eps} >> kemeny.txt
#     julia -O3 main.jl graph/livejournal.txt ${eps} >> kemeny.txt
#     julia -O3 main.jl graph/orkut.txt ${eps} >> kemeny.txt
# done

# julia -O3 main.jl graph/youtube.txt

# julia -O3 main.jl graph/dblp.txt

# julia -O3 main.jl graph/orkut.txt