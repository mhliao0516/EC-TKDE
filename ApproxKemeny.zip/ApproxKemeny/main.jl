include("graph.jl")
include("tool.jl")
using Laplacians

filename = string(ARGS[1])

println("reading graphs...")

networkType = "unweighted"

G = readGraph(filename, networkType)

epsilonA = parse(Float64, ARGS[2])

function Kemeny(G, epsilonA)
	T = time()
    L = getSparseL(G)
	A = getSparseA(G)
	n = G.n
	deg = zeros(n)
	degsq = zeros(n)
    for i = 1:n
        deg[i] = L[i,i]
        degsq[i] = sqrt(L[i,i])
    end
    m = G.m
    # epsilonA = 0.5
	println("epsilonA: ", epsilonA)
    # sol = chol_lap(A)
	tol = epsilonA*(n^(-2.5))/(3*sqrt(2))
	sol = approxchol_lap(A, tol=tol)
	M = ceil(Int,48*log(2*n)*epsilonA^(-2))
	println("M: ", M)
	# tol = 1e-5
	# M = 10
	# sol = approxchol_lap(A, tol=tol)
	U = wtedEdgeVertexMat(A)
	s = 0.0
	for i = 1:M
		dx = degsq.*(2.0*rand(0:1, n)-ones(n))
		y = dx-deg*(transpose(ones(n))*dx/(2.0*m))
		# y = dx-dx/(2.0*m)
		z = sol(y)
		s = s+(norm(U*z))^2
		println("solving linear system: ", i, " time: ", time()-T)
		T = time()
	end
	return s/M
end

outFName1=string(ARGS[1],"-",epsilonA,"-result.txt")
outFName2=string(ARGS[1],"-",epsilonA,"-time.txt")
w1 = open(outFName1, "a")
w2 = open(outFName2, "a")

for i = 1:20
	t0 = time()
	kc = Kemeny(G, epsilonA)
	t1 = time()
	println("kc: ", kc, " time: ", t1-t0, " epsilon: ", epsilonA)
	println(w1, kc)
	println(w2, t1-t0)
end

close(w1)
close(w2)