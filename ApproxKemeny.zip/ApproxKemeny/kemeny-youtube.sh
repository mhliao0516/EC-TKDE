eps_arr=(0.5 0.4 0.3 0.2 0.1)

for i in {1..1}
do
    for eps in "${eps_arr[@]}"
    do
        julia -O3 main.jl graph/youtube.txt ${eps}
    done
done