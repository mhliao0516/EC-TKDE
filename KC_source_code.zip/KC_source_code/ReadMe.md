To reproduce the results, 

run

'''
bash kemeny-astro-ph.sh
bash diagonal-astro-ph.sh
bash process-data.sh

'''