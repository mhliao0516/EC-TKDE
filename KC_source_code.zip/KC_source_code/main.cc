#include <iostream>
#include <vector>
#include <cmath>
#include <gflags/gflags.h>
#include <sys/time.h>
#include <fstream>
#include <iomanip>

#include "graph.h"
#include "methods.h"
using namespace std;
using namespace Eigen;

DEFINE_string(file_name, "", "file name");
DEFINE_string(method, "exact", "method");
DEFINE_string(smethod, "loop-erased-walk", "smethod");
DEFINE_string(filename, "", "filename");
DEFINE_int32(samples, 10, "samples");

double get_current_time_sec()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}

bool maxScoreCmp(const pair<int, double> &a, const pair<int, double> &b)
{
  return a.second > b.second;
}

int main(int argc, char *argv[])
{
  gflags::SetUsageMessage("This is a program to test gflags");
  gflags::ParseCommandLineFlags(&argc, &argv, true);

  graph_t G;
  cout << "read graph" << endl;
  int landmark = read_graph_degree(FLAGS_file_name, G);
  int n = G.size();
  cout << "cout # of vertices: " << n << endl;
  cerr << "# of vertices: " << n << endl;

  vector<int> bfs_parent;
  vector<int> bfs_order;
  compute_BFS_tree(G, bfs_parent, bfs_order, landmark);

  if (FLAGS_method == "kemeny") {
    cout << "kemeny constant computation ..." << endl;
    cout << "number of samples: " << FLAGS_samples << endl;
    double gt;
    ifstream gt_in("result/" + FLAGS_filename + "-kemeny-gt.txt");
    if (gt_in.good())
    {
      cerr << "ground-truth has been generated!" << endl;
      gt_in >> gt;
    } else {
      kemeny_gt(G, landmark, 100000, FLAGS_filename);
    }
    gt_in.close();

    double kemeny;
    if(FLAGS_smethod == "random-walk") kemeny = kemeny_random_walk(G, 25791, FLAGS_samples, FLAGS_filename);
    else if(FLAGS_smethod == "loop-erased-walk") kemeny = kemeny_loop_erased_walk(G, landmark, FLAGS_samples, FLAGS_filename);
    else if(FLAGS_smethod == "spanning-tree") kemeny = kemeny_spanning_tree(G, landmark, FLAGS_samples, FLAGS_filename, bfs_parent);
    ofstream fout("result/" + FLAGS_filename + "-kemeny-" + FLAGS_smethod + "-abs-error-" + to_string(FLAGS_samples) + ".txt", ios::app);
    fout << setprecision(16) << abs(kemeny-gt) << "\n";
    fout.close();

    ofstream fout1("result/" + FLAGS_filename + "-kemeny-" + FLAGS_smethod + "-relative-error-" + to_string(FLAGS_samples) + ".txt", ios::app);
    fout1 << setprecision(16) << abs(kemeny-gt)/gt << "\n";
    fout1.close();

    return 0;
  }

  if(FLAGS_method == "diagonal") {
    cout << "computing diagonal of Laplacian pseudo-inverse ..." << endl;

    vector<double> gt(n, 0);
    ifstream gt_in("result/" + FLAGS_filename + "-digonal-gt.txt");
    if (gt_in.good())
    {
      cerr << "ground-truth has been generated!" << endl;
      for(int i=0; i<n; i++) {
        gt_in >> gt[i];
      }
    } else {
      gt = diagonal_gt(G, landmark, 100000, FLAGS_filename);
    }
    gt_in.close();
    
    vector<double> diagonal;
    if(FLAGS_smethod == "loop-erased-walk") diagonal = diagonal_loop_erased_walk(G, landmark, FLAGS_samples, FLAGS_filename);
    else if(FLAGS_smethod == "spanning-tree") diagonal = diagonal_spanning_tree(G, landmark, FLAGS_samples, FLAGS_filename, bfs_parent);

    double max_relative_err = 0;
    double l1_err = 0.;
    for(int i=0; i<n; i++) {
      l1_err += abs(diagonal[i]-gt[i]);
      if(abs(diagonal[i]-gt[i])/gt[i]>max_relative_err) max_relative_err = abs(diagonal[i]-gt[i])/gt[i];
    }
    ofstream fout("result/" + FLAGS_filename + "-diagonal-" + FLAGS_smethod + "-max-error-" + to_string(FLAGS_samples) + ".txt", ios::app);
    fout << setprecision(16) << abs(max_relative_err) << "\n";
    fout.close();
    ofstream fout1("result/" + FLAGS_filename + "-diagonal-" + FLAGS_smethod + "-l1-error-" + to_string(FLAGS_samples) + ".txt", ios::app);
    fout1 << setprecision(16) << abs(l1_err) << "\n";
    fout1.close();
  }

  if(FLAGS_method == "process") {
    cout << "process" << endl;
    process_data_kemeny(G, FLAGS_samples, FLAGS_method, FLAGS_smethod, FLAGS_filename);
    process_data_diagonal(G, FLAGS_samples, FLAGS_method, FLAGS_smethod, FLAGS_filename);
  }

  return 0;
}