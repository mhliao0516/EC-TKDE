samples_arr=(1 10 100 1000 10000)

make

for sample in "${samples_arr[@]}"
do
    for i in {1..100}
    do
        ./main --filename astro-ph --file_name ./graphs/astro-ph.txt --method kemeny --smethod loop-erased-walk --pairs node -samples ${sample} >> kemeny-astro-ph.txt
        ./main --filename astro-ph --file_name ./graphs/astro-ph.txt --method kemeny --smethod spanning-tree --pairs node -samples ${sample} >> kemeny-astro-ph.txt
    done
done

# for sample in "${samples_arr[@]}"
# do
#     for i in {1..100}
#     do
#         ./main --filename astro-ph --file_name ./graphs/astro-ph.txt --method kemeny --smethod random-walk --pairs node -samples ${sample} >> kemeny-astro-ph.txt
#     done
# done