#include <iostream>
#include <queue>
#include <stack>
#include <sys/time.h>
#include <fstream>
#include "graph.h"
#include "methods.h"
#include "alias.h"
#include <iomanip> 

class pqcompare
{
  bool reverse;
public:
  pqcompare(const bool& revparam=false)
    {reverse=revparam;}
  bool operator() (const pair<int, double>& lhs, const pair<int, double>&rhs) const
  {
    if (reverse) return (lhs.second > rhs.second);
    else return (lhs.second < rhs.second);
  }
};

double get_current_time_sec_method()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}

double kemeny_random_walk(graph_t &G, int l, int N, string& filename) {
    srand((unsigned)time(NULL));
    Random R = Random(unsigned(rand()));
    int n = G.size();
    int m = num_of_edges(G);

    double t_start = get_current_time_sec_method();
    vector<double> current_status(n, 0);
    for(int i=0; i<n; i++) current_status[i] = i;

    double C;

    for(size_t i = 0; i < N; i++) {
      if(i % 1 == 0) cerr << i << endl;
      for(int k=0; k<n; k++) {
        int s = k;
        int u = s;
        for(int j=0; j<l; j++) {
          u = G[u][random() % G[u].size()];
          if(u == k) C++;
        }
      }
    }
    double kemeny = C/(double)N+n-1.-l;

    double t_end = get_current_time_sec_method();

    double time = t_end - t_start;
  
    cout << "time : " << t_end - t_start << endl;
    cout << setprecision(14) << "kemeny constant: " << kemeny << endl;

    ofstream fout("result/" + filename + "-kemeny-random-walk-" + to_string(N) + ".txt", ios::app);
    fout << setprecision(16) << kemeny << "\n";
    fout.close();

    ofstream fout1("result/" + filename + "-kemeny-random-walk-time-" + to_string(N) + ".txt", ios::app);
    fout1 << setprecision(16) << time << "\n";
    fout1.close();

    return kemeny;
}

void kemeny_v_absorbed_walk(graph_t &G, int v, int N, string& filename) {
    srand((unsigned)time(NULL));
    Random R = Random(unsigned(rand()));
    int n = G.size();
    int m = num_of_edges(G);

    double t_start = get_current_time_sec_method();
    vector<double> result(n, 0);
    double lvv = 0.;

    for(size_t i = 0; i < N; i++) {
      if(i % 1 == 0) cerr << i << endl;
      for(int k=0; k<n; k++) {
        double cnt_k = 0.;
        int s = k;
        int u = s;
        while (u != v) {
          if(u == k) result[k] += 1./N;
          cnt_k++;
          u = G[u][random() % G[u].size()];
        }
        lvv += cnt_k*G[k].size()/2./m/N;
      }
    }
    double trace = 0.;
    for(int i=0; i<n; i++) trace += result[i];
    double kemeny = trace - lvv;

    double t_end = get_current_time_sec_method();
    double time = t_end - t_start;
  
    cout << "time : " << t_end - t_start << endl;
    cout << setprecision(14) << "kemeny constant: " << kemeny << endl;
    cout << setprecision(14) << "lvv: " << lvv << endl;
    cout << setprecision(14) << "trace: " << trace << endl;

    ofstream fout("result/" + filename + "-kemeny-v-absorbed-walk-" + to_string(N) + ".txt", ios::app);
    fout << setprecision(16) << kemeny << "\n";
    fout.close();

    ofstream fout1("result/" + filename + "-kemeny-v-absorbed-walk-time-" + to_string(N) + ".txt", ios::app);
    fout1 << setprecision(16) << time << "\n";
    fout1.close();
}

void kemeny_gt(graph_t &G, int v, int N, string& filename) {
    srand((unsigned)time(NULL));
    Random R = Random(unsigned(rand()));
    int n = G.size();
    int m = num_of_edges(G);
    queue<int> q;
    q.push(v);
    bool* is_visited = new bool[n];
    for(int i=0; i<n; i++) is_visited[i] = false;
    while(!q.empty()) {
      int node = q.front();
      q.pop();
      is_visited[node] = true;
      for(int i=0; i<G[node].size(); i++) {
        if(!is_visited[G[node][i]]) q.push(G[node][i]);
      }
    }
    int component_size = 0;
    for(int i=0; i<n; i++) {
      if(is_visited[i]) component_size++;
    }
    cout << "component size: " << component_size << endl;

    double t_start = get_current_time_sec_method();
    vector<double> result(n, 0);
    double cnt_sum = 0.;

    for(size_t i = 0; i < N; i++) {
      if(i % 1000 == 0) cerr << i << endl;
      int cnt = 0;
      vector<bool> intree(n, false);
      vector<int> next(n, -1);
      intree[v] = true;
      for (int j=0; j<n; j++) {
        if(intree[j] || (!is_visited[j])) continue;
        int u = j;
        ++cnt;
        result[u] += 1./N;
        while(!intree[u]) {
          next[u] = G[u][random() % G[u].size()];
          u = next[u];
          result[u] += 1./N;
          ++cnt;
        }
        result[u] -= 1./N;
        --cnt;
        u = j;
        while(!intree[u]) {
          intree[u] = true;
          u = next[u];
        }
      }
      cnt_sum += cnt;
    }
    cout << setprecision(14) << "average random walk length: " << cnt_sum/N << endl;

    double lvv = 0;
    double t_walk_start = get_current_time_sec_method();
    vector<pair<int, double> > aliasP;
    for(int i = 0; i < n; i++) {
        aliasP.push_back(pair<int, double>(i, G[i].size()/2./m));
    }        
    Alias alias = Alias(aliasP);

    int n2 = 10*N;
    for(size_t i = 0; i < n2; i++) {
      // int s = random() % G.size();
      int s = alias.generateRandom(R);
      int u = s;
      double cnt_s = 0;
      while (u != v) {
        u = G[u][random() % G[u].size()];
        cnt_s++;
      }
      // lvv += cnt_s*n*G[s].size()/2/num_of_edges(G)/n2;
      lvv += cnt_s/n2;
    }
    double t_walk_end = get_current_time_sec_method();
    cout << "walk time: " << t_walk_end - t_walk_start << endl;

    double kemeny = cnt_sum/N-lvv;

    double t_end = get_current_time_sec_method();

    double time = t_end - t_start;
  
    cout << "time : " << t_end - t_start << endl;
    cout << setprecision(14) << "kemeny constant: " << kemeny << endl;
    cout << setprecision(14) << "lvv: " << lvv << endl;

    ofstream fout("result/" + filename + "-kemeny-gt.txt", ios::app);
    fout << setprecision(16) << kemeny << "\n";
    fout.close();
}

double kemeny_loop_erased_walk(graph_t &G, int v, int N, string& filename) {
    srand((unsigned)time(NULL));
    Random R = Random(unsigned(rand()));
    int n = G.size();
    int m = num_of_edges(G);
    queue<int> q;
    q.push(v);
    bool* is_visited = new bool[n];
    for(int i=0; i<n; i++) is_visited[i] = false;
    while(!q.empty()) {
      int node = q.front();
      q.pop();
      is_visited[node] = true;
      for(int i=0; i<G[node].size(); i++) {
        if(!is_visited[G[node][i]]) q.push(G[node][i]);
      }
    }
    int component_size = 0;
    for(int i=0; i<n; i++) {
      if(is_visited[i]) component_size++;
    }
    cout << "component size: " << component_size << endl;

    double t_start = get_current_time_sec_method();
    vector<double> result(n, 0);
    double cnt_sum = 0.;

    for(size_t i = 0; i < N; i++) {
      if(i % 1000 == 0) cerr << i << endl;
      int cnt = 0;
      vector<bool> intree(n, false);
      vector<int> next(n, -1);
      intree[v] = true;
      for (int j=0; j<n; j++) {
        if(intree[j] || (!is_visited[j])) continue;
        int u = j;
        ++cnt;
        result[u] += 1./N;
        while(!intree[u]) {
          next[u] = G[u][random() % G[u].size()];
          u = next[u];
          result[u] += 1./N;
          ++cnt;
        }
        result[u] -= 1./N;
        --cnt;
        u = j;
        while(!intree[u]) {
          intree[u] = true;
          u = next[u];
        }
      }
      cnt_sum += cnt;
    }
    cout << setprecision(14) << "average random walk length: " << cnt_sum/N << endl;

    double lvv = 0;
    double t_walk_start = get_current_time_sec_method();
    vector<pair<int, double> > aliasP;
    for(int i = 0; i < n; i++) {
        aliasP.push_back(pair<int, double>(i, G[i].size()/2./m));
    }        
    Alias alias = Alias(aliasP);

    int n2 = 10*N;
    for(size_t i = 0; i < n2; i++) {
      // int s = random() % G.size();
      int s = alias.generateRandom(R);
      int u = s;
      double cnt_s = 0;
      while (u != v) {
        u = G[u][random() % G[u].size()];
        cnt_s++;
      }
      // lvv += cnt_s*n*G[s].size()/2/num_of_edges(G)/n2;
      lvv += cnt_s/n2;
    }
    double t_walk_end = get_current_time_sec_method();
    cout << "walk time: " << t_walk_end - t_walk_start << endl;

    double kemeny = cnt_sum/N-lvv;

    double t_end = get_current_time_sec_method();

    double time = t_end - t_start;
  
    cout << "time : " << t_end - t_start << endl;
    cout << setprecision(14) << "kemeny constant: " << kemeny << endl;
    cout << setprecision(14) << "lvv: " << lvv << endl;

    ofstream fout("result/" + filename + "-kemeny-loop-erased-walk-" + to_string(N) + ".txt", ios::app);
    fout << setprecision(16) << kemeny << "\n";
    fout.close();

    ofstream fout1("result/" + filename + "-kemeny-loop-erased-walk-time-" + to_string(N) + ".txt", ios::app);
    fout1 << setprecision(16) << time << "\n";
    fout1.close();

    return kemeny;
}

double kemeny_spanning_tree(graph_t &G, int v, int N, string& filename, vector<int> &bfs_parent) {
    srand((unsigned)time(NULL));
    Random R = Random(unsigned(rand()));
    int n = G.size();
    int m = num_of_edges(G);

    queue<int> q;
    q.push(v);
    bool* is_visited = new bool[n];
    for(int i=0; i<n; i++) is_visited[i] = false;
    while(!q.empty()) {
      int node = q.front();
      q.pop();
      is_visited[node] = true;
      for(int i=0; i<G[node].size(); i++) {
        if(!is_visited[G[node][i]]) q.push(G[node][i]);
      }
    }
    int component_size = 0;
    for(int i=0; i<n; i++) {
      if(is_visited[i]) component_size++;
    }
    cout << "component size: " << component_size << endl;

    double t_start = get_current_time_sec_method();
    vector<double> result(n, 0);
    long long cnt_sum = 0;
    double lvv = 0.;
    for(size_t i = 0; i < N; i++) {
      if(i % 1000 == 0) cerr << i << endl;
      int cnt = 0;
      vector<bool> intree(n, false);
      vector<int> next(n, -1);
      intree[v] = true;
      for (int j=0; j<n; j++) {
        if(intree[j] || (!is_visited[j])) continue;
        int u = j;
        ++cnt;
        // result[u] += 1./N;
        while(!intree[u]) {
          next[u] = G[u][random() % G[u].size()];
          u = next[u];
          // result[u] += 1./N;
          ++cnt;
        }
        // result[u] -= 1./N;
        u = j;
        while(!intree[u]) {
          intree[u] = true;
          u = next[u];
        }
      }
      cnt_sum += cnt;


      cout << "build childPtr and siblingPtr" << endl;
      // build childPtr and siblingPtr
      vector<int> childPtr(n, -1);
      vector<int> siblingPtr(n,-1);

      int visitNodes = 0;
      vector<bool> visited(n, false);
      for(int k=0; k<n; k++) {
          int u = k;
          while(!visited[u]) {
            visited[u] = true;
            ++visitNodes;
            int parentU = next[u];
            if(next[u] != -1) {
              assert(siblingPtr[u] == -1);
              if(childPtr[parentU] != -1) {
                siblingPtr[u] = childPtr[parentU];
              }
              childPtr[parentU] = u;
              u = parentU;
            } else {
              break;
            }
          }
          if(visitNodes == n) break; 
      }

      cout << "do DFS on the sampled tree" << endl;
      // do DFS on the sampled tree
      vector<int> tVisit(n, 0);
      vector<int> tFinish(n, 0);

      std::stack<std::pair<int, int>> stack;
      stack.push({v, childPtr[v]});

      int timestamp = 0;
      do {
        int nodeu = stack.top().first;
        int nodev = stack.top().second;

        if(nodev == -1) {
          stack.pop();
          tFinish[nodeu] = ++timestamp;
        } else {
          stack.top().second = siblingPtr[nodev];
          tVisit[nodev] = ++timestamp;
          stack.push({nodev, childPtr[nodev]});
        }
      } while (!stack.empty());

      vector<double> support(n, 0.);
      for(int k=0; k<n; k++) {
        int u = k;
        while(u!=v) {
          support[u] += G[k].size()/2./m; 
          u = next[u];
        }
      }

      cout << "compare BFS tree with sampled tree and aggragate" << endl;
      // compare BFS tree with sampled tree and aggragate
      for(int k=0; k<n; k++) {
        int u = k;

        int p = bfs_parent[u];
        int c = u;

        while (p != -1) {
          int e1 = p, e2 = c;
          bool reverse = false;
          if(e1 != next[e2]) {
            if(e2 != next[e1]) {
              c = p;
              p = bfs_parent[p];
              continue;
            }
            std::swap(e1, e2);
            reverse = true;
          }

          if(tVisit[u] >= tVisit[e2] && tFinish[u] <= tFinish[e2]) {
            if(reverse) {
              result[u] -= 1./N;
              lvv -= G[k].size()*support[e2]/N;
            } else {
              result[u] += 1./N;
              lvv += G[k].size()*support[e2]/N;
            }
          }
          c = p;
          p = bfs_parent[p];
        }
      }
    }
    double kemeny = 0.;
    for(int i=0; i<n; i++) {
      kemeny += result[i]*G[i].size();
    }
    double t_end = get_current_time_sec_method();

    cout << setprecision(14) << "average spanning tree trace: " << kemeny << endl;

    cout << "time : " << t_end - t_start << endl;
    kemeny -= lvv;
    cout << setprecision(14) << "lvv: " << lvv << endl;
    cout << setprecision(14) << "kemeny constant: " << kemeny << endl;

    double time = t_end - t_start;

    ofstream fout("result/" + filename + "-kemeny-spanning-tree-" + to_string(N) + ".txt", ios::app);
    fout << setprecision(16) << kemeny << "\n";
    fout.close();

    ofstream fout1("result/" + filename + "-kemeny-spanning-tree-time-" + to_string(N) + ".txt", ios::app);
    fout1 << setprecision(16) << time << "\n";
    fout1.close();

    return kemeny;
}

vector<double> diagonal_gt(graph_t &G, int v, int N, string& filename) {
    srand((unsigned)time(NULL));
    Random R = Random(unsigned(rand()));
    int n = G.size();
    double t_push_start = get_current_time_sec_method();
    double eps = 2;
    vector<double> res(n, 0);
    double r_sum = 0;
    for(int i=0; i<n; i++) {
      res[i] = 1./n;
      if(i != v) r_sum += res[i];
    }

    vector<double> push_result(n, 0);
    vector<bool> isInQueue(n, false);
    queue<int> r_q;

    cout << "push r_sum: " << r_sum << endl;

    for(int i=0; i<n; i++) {
      if(i!= v && res[i]<eps/n) {
        r_q.push(i);
        isInQueue[i] = true;
      }
    }

    while(r_q.size()>0) {
      int current_node = r_q.front();
      r_q.pop();
      isInQueue[current_node] = false;
      push_result[current_node] += res[current_node];
      double increment = res[current_node];
      res[current_node] = 0;
      for(int i=0; i<G[current_node].size(); i++) {
        if(G[current_node][i] == v) {
          r_sum -= increment/G[current_node].size();
        } else {
          int updateNode = G[current_node][i];
          res[updateNode] += increment/G[current_node].size();
          if(!isInQueue[updateNode] && res[updateNode] >= eps/n) {
            r_q.push(updateNode);
            isInQueue[updateNode] = true;
          }
        }
      }
    }
    cout << "r_sum: " << r_sum << endl;

    for(int i=0; i<n; i++) {
      if(i != v) push_result[i] /= G[i].size();
    }
    double t_push_end = get_current_time_sec_method();
    cout << "push time: " << t_push_end - t_push_start << endl;

    double t_walk_start = get_current_time_sec_method();
    vector<pair<int, double> > aliasP;
    for(int i = 0; i < n; i++) {
        if(i!=v) aliasP.push_back(pair<int, double>(i, res[i]/r_sum));
    }        
    Alias alias = Alias(aliasP);

    double walk_num = 1000000;
    for(int i=0; i<walk_num; i++) {
      int s = alias.generateRandom(R);
      int u = s;
      while (u != v) {
        push_result[u] += r_sum / walk_num;
        u = G[u][random() % G[u].size()];
      }
    }
    for(int i=0; i<n; i++) {
      if(i != v) push_result[i] /= G[i].size();
    }
    double t_walk_end = get_current_time_sec_method();
    cout << "walk time: " << t_walk_end - t_walk_start << endl;

    vector<double> diagonal(n,0);

    double t_start = get_current_time_sec_method();
    vector<double> result(n, 0);
    double cnt_sum = 0.;

    for(size_t i = 0; i < N; i++) {
      if(i % 1000 == 0) cerr << i << endl;
      int cnt = 0;
      vector<bool> intree(n, false);
      vector<int> next(n, -1);
      intree[v] = true;
      for (int j=0; j<n; j++) {
        if(intree[j]) continue;
        int u = j;
        ++cnt;
        result[u] += 1./N;
        while(!intree[u]) {
          next[u] = G[u][random() % G[u].size()];
          u = next[u];
          result[u] += 1./N;
          ++cnt;
        }
        result[u] -= 1./N;
        --cnt;
        u = j;
        while(!intree[u]) {
          intree[u] = true;
          u = next[u];
        }
      }
      cnt_sum += cnt;
    }
    cout << setprecision(14) << "average random walk length: " << cnt_sum/N << endl;
    double t_end = get_current_time_sec_method();

    for(int i=0; i<n; i++) {
      if(i!=v) diagonal[v] += push_result[i]/n;
    }

    for(int i=0; i<n; i++) {
      if(i!=v) diagonal[i] = result[i]/G[i].size() - 2*push_result[i] + diagonal[v]; 
    }

    double trace = 0;
    vector<double> closeness(n,0);
    for(int i=0; i<n; i++) trace += diagonal[i];
    for(int i=0; i<n; i++) closeness[i] = (n-1.)/(n*diagonal[i]+trace);
    cout << "kirchhoff index: " << trace << endl;

    ofstream fout("result/" + filename + "-digonal-gt.txt");
    for(int i=0; i<n; i++) fout << setprecision(16) << closeness[i] << "\n";
    fout.close();

    return closeness;
}

vector<double> diagonal_loop_erased_walk(graph_t &G, int v, int N, string& filename) {
    double t_start = get_current_time_sec_method();
    srand((unsigned)time(NULL));
    Random R = Random(unsigned(rand()));
    int n = G.size();

    int m = num_of_edges(G);

    queue<int> q;
    q.push(v);
    bool* is_visited = new bool[n];
    for(int i=0; i<n; i++) is_visited[i] = false;
    while(!q.empty()) {
      int node = q.front();
      q.pop();
      is_visited[node] = true;
      for(int i=0; i<G[node].size(); i++) {
        if(!is_visited[G[node][i]]) q.push(G[node][i]);
      }
    }
    int component_size = 0;
    for(int i=0; i<n; i++) {
      if(is_visited[i]) component_size++;
    }
    cout << "component size: " << component_size << endl;

    vector<double> push_result(n, 0);
    double walk_num = 100*N;
    for(int i=0; i<walk_num; i++) {
      int s = random() % n;
      if(!is_visited[s]) continue;
      int u = s;
      while (u != v) {
        push_result[u] += 1. / G[u].size() / walk_num;
        u = G[u][random() % G[u].size()];
      }
    }

    vector<double> diagonal(n,0);

    vector<double> result(n, 0);
    double cnt_sum = 0.;

    for(size_t i = 0; i < N; i++) {
      if(i % 1000 == 0) cerr << i << endl;
      int cnt = 0;
      vector<bool> intree(n, false);
      vector<int> next(n, -1);
      intree[v] = true;
      for (int j=0; j<n; j++) {
        if(intree[j] || !is_visited[j]) continue;
        int u = j;
        ++cnt;
        result[u] += 1./N;
        while(!intree[u]) {
          next[u] = G[u][random() % G[u].size()];
          u = next[u];
          result[u] += 1./N;
          ++cnt;
        }
        result[u] -= 1./N;
        --cnt;
        u = j;
        while(!intree[u]) {
          intree[u] = true;
          u = next[u];
        }
      }
      cnt_sum += cnt;
    }
    cout << setprecision(14) << "average random walk length: " << cnt_sum/N << endl;
    double t_end = get_current_time_sec_method();

    for(int i=0; i<n; i++) {
      if(i!=v) diagonal[v] += push_result[i]/n;
    }

    for(int i=0; i<n; i++) {
      if(i!=v) diagonal[i] = result[i]/G[i].size() - 2*push_result[i] + diagonal[v]; 
    }

    double trace = 0;
    vector<double> closeness(n,0);
    for(int i=0; i<n; i++) trace += diagonal[i];
    for(int i=0; i<n; i++) closeness[i] = diagonal[i];
    cout << "kirchhoff index: " << trace << endl;

    ofstream fout1("result/" + filename + "-diagonal-loop-erased-walk-time-" + to_string(N) + ".txt", ios::app);
    fout1 << setprecision(16) << t_end-t_start << "\n";
    fout1.close();

    return closeness;
}

vector<double> diagonal_spanning_tree(graph_t &G, int v, int N, string& filename, vector<int> &bfs_parent) {
    double t_start = get_current_time_sec_method();
    int n = G.size();
    srand((unsigned)time(NULL));

    vector<double> push_result(n, 0);
    double walk_num = 100*N;
    for(int i=0; i<walk_num; i++) {
      int s = random() % n;
      int u = s;
      while (u != v) {
        push_result[u] += 1./ G[u].size() / walk_num;
        u = G[u][random() % G[u].size()];
      }
    }

    vector<double> result(n, 0);
    vector<double> diagonal(n, 0);
    long long cnt_sum = 0;
    double lvv = 0.;
    for(size_t i = 0; i < N; i++) {
      if(i % 1000 == 0) cerr << i << endl;
      int cnt = 0;
      vector<bool> intree(n, false);
      vector<int> next(n, -1);
      intree[v] = true;
      for (int j=0; j<n; j++) {
        if(intree[j]) continue;
        int u = j;
        ++cnt;
        while(!intree[u]) {
          next[u] = G[u][random() % G[u].size()];
          u = next[u];
          ++cnt;
        }
        u = j;
        while(!intree[u]) {
          intree[u] = true;
          u = next[u];
        }
      }
      cnt_sum += cnt;

      // build childPtr and siblingPtr
      vector<int> childPtr(n, -1);
      vector<int> siblingPtr(n,-1);

      int visitNodes = 0;
      vector<bool> visited(n, false);
      for(int k=0; k<n; k++) {
          int u = k;
          while(!visited[u]) {
            visited[u] = true;
            ++visitNodes;
            int parentU = next[u];
            if(next[u] != -1) {
              assert(siblingPtr[u] == -1);
              if(childPtr[parentU] != -1) {
                siblingPtr[u] = childPtr[parentU];
              }
              childPtr[parentU] = u;
              u = parentU;
            } else {
              break;
            }
          }
          if(visitNodes == n) break; 
      }

      // do DFS on the sampled tree
      vector<int> tVisit(n, 0);
      vector<int> tFinish(n, 0);

      std::stack<std::pair<int, int>> stack;
      stack.push({v, childPtr[v]});

      int timestamp = 0;
      do {
        int nodeu = stack.top().first;
        int nodev = stack.top().second;

        if(nodev == -1) {
          stack.pop();
          tFinish[nodeu] = ++timestamp;
        } else {
          stack.top().second = siblingPtr[nodev];
          tVisit[nodev] = ++timestamp;
          stack.push({nodev, childPtr[nodev]});
        }
      } while (!stack.empty());

      // compare BFS tree with sampled tree and aggragate
      for(int k=0; k<n; k++) {
        int u = k;

        int p = bfs_parent[u];
        int c = u;

        while (p != -1) {
          int e1 = p, e2 = c;
          bool reverse = false;
          if(e1 != next[e2]) {
            if(e2 != next[e1]) {
              c = p;
              p = bfs_parent[p];
              continue;
            }
            std::swap(e1, e2);
            reverse = true;
          }

          if(tVisit[u] >= tVisit[e2] && tFinish[u] <= tFinish[e2]) {
            if(reverse) {
              result[u] -= 1./N;
            } else {
              result[u] += 1./N;
            }
          }
          c = p;
          p = bfs_parent[p];
        }
      }
    }

    double t_end = get_current_time_sec_method();

    for(int i=0; i<n; i++) {
      if(i!=v) diagonal[v] += push_result[i]/n;
    }

    for(int i=0; i<n; i++) {
      if(i!=v) diagonal[i] = result[i] - 2*push_result[i] + diagonal[v]; 
    }

    double trace = 0;
    vector<double> closeness(n,0);
    for(int i=0; i<n; i++) trace += diagonal[i];
    for(int i=0; i<n; i++) closeness[i] = (n-1.)/(n*diagonal[i]+trace);
    cout << "kirchhoff index: " << trace << endl;

    ofstream fout1("result/" + filename + "-diagonal-spanning-tree-time-" + to_string(N) + ".txt", ios::app);
    fout1 << setprecision(16) << t_end-t_start << "\n";
    fout1.close();

    return closeness;
}

void kemeny_single_v_absorbed_walk(graph_t &G, int v, int N, string& filename) {
    srand((unsigned)time(NULL));
    Random R = Random(unsigned(rand()));
    int n = G.size();
    int m = num_of_edges(G);

    double t_start = get_current_time_sec_method();
    vector<double> result(n, 0);
    double lvv = 0.;

    int source = 2000;
    vector<double> psv(n, 0);
    for(int i=0; i<N; i++) {
      int u = source;
      bool* is_visited = new bool[n]();
      while(u != v) {
        result[u] += 1./N;
        if(!is_visited[u]) {
          psv[u] += 1./N;
          is_visited[u] = true;
        }
        u = G[u][random() % G[u].size()];
      }
      delete[] is_visited;
    }

    double trace = 0.;
    double eps = 1e-4;
    for(int i=0; i<n; i++) {
      if(psv[i]>eps/N) trace += result[i]/psv[i];
      else trace += result[i]*N/eps;
    }

    double t_walk_start = get_current_time_sec_method();
    vector<pair<int, double> > aliasP;
    for(int i = 0; i < n; i++) {
        aliasP.push_back(pair<int, double>(i, G[i].size()/2./m));
    }        
    Alias alias = Alias(aliasP);

    for(size_t i = 0; i < N; i++) {
      int s = alias.generateRandom(R);
      int u = s;
      double cnt_s = 0;
      while (u != v) {
        u = G[u][random() % G[u].size()];
        cnt_s++;
      }
      lvv += (double)cnt_s/N;
    }
    double t_walk_end = get_current_time_sec_method();
    cout << "walk time: " << t_walk_end - t_walk_start << endl;
    
    double kemeny = trace - lvv;

    double t_end = get_current_time_sec_method();
    double time = t_end - t_start;
  
    cout << "time : " << t_end - t_start << endl;
    cout << setprecision(14) << "kemeny constant: " << kemeny << endl;
    cout << setprecision(14) << "lvv: " << lvv << endl;
    cout << setprecision(14) << "trace: " << trace << endl;

    ofstream fout("result/" + filename + "-kemeny-single-v-absorbed-walk-" + to_string(N) + ".txt", ios::app);
    fout << setprecision(16) << kemeny << "\n";
    fout.close();

    ofstream fout1("result/" + filename + "-kemeny-single-v-absorbed-walk-time-" + to_string(N) + ".txt", ios::app);
    fout1 << setprecision(16) << time << "\n";
    fout1.close();
}

void process_data_kemeny(graph_t &G, int N, string& method, string& smethod, string& filename) {
    int sample = 100;
    cout << "process data kemeny: " << method << " " << filename << endl;

    ifstream fin("result/" + filename + "-kemeny-" + smethod + "-relative-error-" + to_string(N) + ".txt", ios::app);
    vector<double> relative_arr(sample, 0);
    for(int i=0; i<sample; i++) {
      fin >> relative_arr[i];
    }
    fin.close();
    double average_relative_err = 0.;
    for(int i=0; i<sample; i++) {
      average_relative_err += relative_arr[i] / sample;    
    }
    cout << filename << " kemeny average relative error: " << average_relative_err << " N=" << N << " " << smethod << endl;
    double standard_deviation0 = 0.;
    for(int i=0; i<sample; i++) {
      standard_deviation0 += (relative_arr[i]-average_relative_err)*(relative_arr[i]-average_relative_err);
    }
    standard_deviation0 /= sample;
    standard_deviation0 = sqrt(standard_deviation0); 
    cout << filename << " kemeny relative error standard deviation: " << standard_deviation0 << " N=" << N << " " << smethod << endl;

    ifstream fin1("result/" + filename + "-kemeny-" + smethod + "-abs-error-" + to_string(N) + ".txt", ios::app);
    vector<double> abs_arr(sample, 0);
    for(int i=0; i<sample; i++) {
      fin1 >> abs_arr[i];
    }
    fin1.close();
    double average_abs_err = 0.;
    for(int i=0; i<sample; i++) {
      average_abs_err += abs_arr[i] / sample;    
    }
    cout << filename << " kemeny average absolute error: " << average_abs_err << " N=" << N << " " << smethod << endl;
    double standard_deviation = 0.;
    for(int i=0; i<sample; i++) {
      standard_deviation += (abs_arr[i]-average_abs_err)*(abs_arr[i]-average_abs_err);
    }
    standard_deviation /= sample;
    standard_deviation = sqrt(standard_deviation);
    cout << filename << " kemeny absolute error standard deviation: " << standard_deviation << " N=" << N << " " << smethod << endl;

    double time = 0.;
    ifstream fin2("result/" + filename + "-kemeny-" + smethod + "-time-" + to_string(N) + ".txt", ios::app);
    for(int i=0; i<sample; i++) {
      double tmp_time;
      fin2 >> tmp_time;
      time += tmp_time / sample;
    }
    cout << filename << " kemeny average time: " << time << " N=" << N << " " << smethod << endl;
}

void process_data_diagonal(graph_t &G, int N, string& method, string& smethod, string& filename) {
    int sample = 100;
    cout << "process data diagonal: " << method << " " << filename << endl;

    ifstream fin("result/" + filename + "-diagonal-" + smethod + "-max-error-" + to_string(N) + ".txt", ios::app);
    vector<double> relative_arr(sample, 0);
    for(int i=0; i<sample; i++) {
      fin >> relative_arr[i];
    }
    fin.close();
    double average_relative_err = 0.;
    for(int i=0; i<sample; i++) {
      average_relative_err += relative_arr[i] / sample;    
    }
    cout << filename << " diagonal average max relative error: " << average_relative_err << " N=" << N << " " << smethod << endl;
    double standard_deviation0 = 0.;
    for(int i=0; i<sample; i++) {
      standard_deviation0 += (relative_arr[i]-average_relative_err)*(relative_arr[i]-average_relative_err);
    }
    standard_deviation0 /= sample;
    standard_deviation0 = sqrt(standard_deviation0);
    cout << filename << " diagonal max relative error standard deviation: " << standard_deviation0 << " N=" << N << " " << smethod << endl;

    ifstream fin1("result/" + filename + "-diagonal-" + smethod + "-l1-error-" + to_string(N) + ".txt", ios::app);
    vector<double> l1_arr(sample, 0);
    for(int i=0; i<sample; i++) {
      fin1 >> l1_arr[i];
    }
    fin1.close();
    double average_l1_err = 0.;
    for(int i=0; i<sample; i++) {
      average_l1_err += l1_arr[i] / sample;    
    }
    cout << filename << " diagonal average l1 error: " << average_l1_err << " N=" << N << " " << smethod << endl;
    double standard_deviation = 0.;
    for(int i=0; i<sample; i++) {
      standard_deviation += (l1_arr[i]-average_l1_err)*(l1_arr[i]-average_l1_err);
    }
    standard_deviation /= sample;
    standard_deviation = sqrt(standard_deviation);
    cout << filename << " diagonal l1 error standard deviation: " << standard_deviation << " N=" << N << " " << smethod << endl;

    double time = 0.;
    ifstream fin2("result/" + filename + "-diagonal-" + smethod + "-time-" + to_string(N) + ".txt", ios::app);
    for(int i=0; i<sample; i++) {
      double tmp_time;
      fin2 >> tmp_time;
      time += tmp_time / sample;
    }
    cout << filename << " diagonal average time: " << time << " N=" << N << " " << smethod << endl;
}