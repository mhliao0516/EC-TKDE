#pragma once

#include <vector>
#include <string>
#include <Eigen/Sparse>
using namespace std;
using namespace Eigen;

typedef vector<vector<int>> graph_t;
int read_graph_degree(string fn, graph_t &G);
int compute_BFS_tree(graph_t &G, vector<int> &bfs_parent, vector<int> &bfs_order, int landmark);
size_t num_of_edges(graph_t &G);

double closeness_cent(graph_t &G, int u);
vector<int> dijkstra(graph_t &G, int s);
