#include <fstream>
#include <sstream>
#include <iostream>
#include <queue>
#include "graph.h"

const int INF = INT_MAX;
typedef pair<int, int> pii;

vector<int> dijkstra(graph_t &G, int s) {
    int n = G.size();
    vector<int> dist(n, INF);
    dist[s] = 0;
    priority_queue<pii, vector<pii>, greater<pii>> pq;
    pq.push({0, s});
    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();
        for (auto v : G[u]) {
            int w = 1; // assume unweighted graph
            if (dist[v] > dist[u] + w) {
                dist[v] = dist[u] + w;
                pq.push({dist[v], v});
            }
        }
    }
    return dist;
}

double closeness_cent(graph_t &G, int u) {
    int n = G.size();
    vector<int> dist = dijkstra(G, u);
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        if (i == u) continue;
        if (dist[i] != INF) {
            sum += 1.0 / dist[i];
        }
    }
    return sum / (n - 1);
}

int get_id(int index, map<int, int> &dic)
{
  auto it = dic.find(index);
  if (it != dic.end())
  {
    return it->second;
  }
  else
  {
    int id = dic.size();
    dic[index] = id;
    return id;
  }
}

int read_graph_degree(string fn, graph_t &G)
{
  ifstream ifs(fn.c_str());
  string line;
  bool fst = true;
  map<int, int> dic;

  while (getline(ifs, line))
  {
    if (line.size() > 0 && line[0] == '%')
      continue;
    istringstream iss(line);
    if (fst)
    {
      // skip this line
      fst = false;
    }
    else
    {
      int u, v;
      iss >> u >> v;
      if(u >= v) continue;
      u = get_id(u, dic);
      v = get_id(v, dic);
      //      --u, --v;
      if (G.size() <= u)
        G.resize(u + 1);
      if (G.size() <= v)
        G.resize(v + 1);
      G[u].push_back(v);
      G[v].push_back(u);
    }
  }

  int n = G.size();
  int* degree = new int[n]();
  for(int i=0; i<n; i++) {
    degree[i] = G[i].size();
  }
  int maxdegree = 0, maxid = 0;
  for(int i=0; i<n; i++) {
    if(degree[i]>maxdegree) {
      maxdegree = degree[i];
      maxid = i;
    }
  }
  cerr << "maxid: " << maxid << " maxdegree: " << maxdegree << endl;
  delete[] degree;
  return maxid;
}

size_t num_of_edges(graph_t &G)
{
  int res = 0;
  for (size_t u = 0; u < G.size(); u++)
  {
    res += G[u].size();
  }
  return res / 2;
}

int compute_BFS_tree(graph_t &G, vector<int> &bfs_parent, vector<int> &bfs_order, int landmark) {
    // compute a BFS tree from the highest degree node
    int n = G.size();
    bfs_parent.resize(n);
    bfs_order.resize(n);
    bfs_parent[landmark] = -1;
    bfs_order[0] = landmark;

    int order_count = 0;
    int level = 0;
    int* level_arr = new int[n]();
    for(int i=0; i<n; i++) {
      level_arr[i] = 0;
    }

    vector<bool> is_visited(n);
    std::fill(is_visited.begin(), is_visited.end(), false);

    queue<int> q;
    q.push(landmark);
    is_visited[landmark] = true;
    level_arr[landmark] = 0;

    do {
        int currentNode = q.front();
        // cerr << "currentNode: " << currentNode << endl;
        q.pop();
        for(int i=0; i<G[currentNode].size(); i++) {
            int u = G[currentNode][i];
            if(!is_visited[u]) {
              is_visited[u] = true;
              q.push(u);
              level_arr[u] = level_arr[currentNode]+1;
              // cout << level_arr[u] << endl;
              bfs_parent[u] = currentNode;
              bfs_order[++order_count] = u;
            }
        }
    } while (!q.empty());

    cerr << "order count: " << order_count << endl;
    // assert(order_count == n-1);
    for(int i=0; i<n; i++) {
      if(level_arr[i]>level) level = level_arr[i];
    }
    delete[] level_arr;
    return level;
}
