#include "graph.h"
using namespace std;

void kemeny_gt(graph_t &G, int v, int N, string& filename);
double kemeny_random_walk(graph_t &G, int l, int N, string& filename);
void kemeny_single_v_absorbed_walk(graph_t &G, int v, int N, string& filename);
void kemeny_v_absorbed_walk(graph_t &G, int v, int N, string& filename);
double kemeny_loop_erased_walk(graph_t &G, int v, int N, string& filename);
double kemeny_spanning_tree(graph_t &G, int v, int N, string& filename, vector<int> &bfs_parent);

vector<double> diagonal_gt(graph_t &G, int v, int N, string& filename);
vector<double> diagonal_v_absorbed_walk(graph_t &G, int v, int N, string& filename);
vector<double> diagonal_loop_erased_walk(graph_t &G, int v, int N, string& filename);
vector<double> diagonal_spanning_tree(graph_t &G, int v, int N, string& filename, vector<int> &bfs_parent);

void process_data_kemeny(graph_t &G, int N, string& method, string& smethod, string& filename);
void process_data_diagonal(graph_t &G, int N, string& method, string& smethod, string& filename);