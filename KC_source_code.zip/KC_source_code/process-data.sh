samples_arr=(1 10 100 1000 10000)

make

rm process_data.txt

for sample in "${samples_arr[@]}"
do
    for smethod in loop-erased-walk spanning-tree
    do
        ./main --filename astro-ph --file_name ./graphs/astro-ph.txt --method process --smethod ${smethod} --pairs node -samples ${sample} >> process_data.txt
    done
done